# -*- coding: utf-8 -*-
# Import Monkey module from gevent for monkey-patching
from gevent import monkey
# Monkey-patching standart Python library for async working
monkey.patch_all()
# Import WSGI server from Gevent
from gevent.pywsgi import WSGIServer
# Import Compress module from Flask-Compress for compress static
# content (HTML, CSS, JS)
from flask_compress import Compress

from flask import Flask, render_template

app = Flask(__name__)

# Create Compress with default params
compress = Compress()
# Init compress for our Flask app
compress.init_app(app)


@app.route('/')
def hello_world():
    return render_template('index.html')


if __name__ == '__main__':
    # Create WSGI server with params for Repl.it (IP 0.0.0.0, port 8080)
    # for our Flask app
    http_server = WSGIServer(('0.0.0.0', 8080), app)
    # Start WSGI server
    http_server.serve_forever()